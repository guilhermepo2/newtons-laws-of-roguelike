Newton's Laws of RogueLike

Entry for the GMC Jam 7 - Themed Newton's Laws of Movement

The entry is a simple Roguelike where the enemies are inspired on Newton's Laws of Movement, but, BUT! 
They all look the same in the Dungeon... Good Luck!

How to Play

* Arrows:Move Your Character
* E: Attack
* Space: Restart Level

## Enemies

**The Log:** The log will remain sleeping unless acted upon a force :)

**The Light Log:** This log runs faaaaaaaaaaaaast through the dungeon, just when you are defenseless it hits you! And then he runs, fast.

**The Heavy Log:** This logs run sloooooooooooooooooow through the dungeon, and when you are EXPECTING it hits you! Should be easy to avoid.

**The BOMB Log:** The BOMB Log will punish you for hitting it, with the same force, but on opposite direction :)

Credits

Heartbeast(https://learn.heartbeast.co/) - HeartBeast was my first learning resource for GameMaker, 
I rewatched some classes of his Action RPG Course for this entry, also, I watched his Random Dungeon
 Generation video for GameMaker Studio to reach this results.
I used sounds and effects from his course (I'M NOT SURE IF THIS IS ALLOWED, PLEASE MSG ME IF IT ISN'T).

ArMM1998(https://opengameart.org/content/zelda-like-tilesets-and-sprites)
Most of the art is from this link, main character, log enemy, the dungeon tileset was also inspired by this set.
